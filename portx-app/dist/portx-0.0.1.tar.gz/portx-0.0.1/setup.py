# setup.py

import setuptools

setuptools.setup(
    name="portx", 
    version="0.0.1",
    author="Allison Sinnott",
    author_email="allison.sinnott@my.liu.edu",
    description="Final Project",
    packages=setuptools.find_packages(),
    scripts=['print-report.py'],
)
