# -*- coding: utf-8 -*-
"""
Created on Thu Dec 18 18:00:07 2025

@author: Allie
"""