# -*- coding: utf-8 -*-
"""
Created on Thu Dec 18 18:07:31 2025

@author: Allie
"""

import sys
from portx.report import portfolio_report
portfolio_report(sys.argv[1], sys.argv[2], sys.argv[3])